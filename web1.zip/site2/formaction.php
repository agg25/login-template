<?php
session_start();
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'student');
$query = 'select * from stu_info where username = \''.$_SESSION['user'].'\'';
mysqli_query($con,$query);
$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$branch = $_POST['branch'];
	$hostel = $_POST['hostel'];
	$year = $_POST['year'];
	$society = $_POST['society'];
	$insta = $_POST['insta'];
	$link = $_POST['link'];
	$git = $_POST['git'];
	$bio = $_POST['bio'];
if(mysqli_affected_rows($con)>=0){
	
	$query2 = 'delete from stu_info where username = "'.$_SESSION["user"].'"';
	mysqli_query($con,$query2);}
$query = 'insert into stu_info values("'.$_SESSION["user"].'","'.$fname .'","'. $lname.'","'. $branch.'","'. $year .'","'. $hostel.'" ,"'.$society.'","'. $insta.'","'.$link .'","'. $git.'","'. $bio.'")';  
	mysqli_query($con,$query);
	echo $query;


mysqli_close($con);
?>