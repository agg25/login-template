<?php
session_start();
$date = $_POST['date'];
$ename = $_POST['ename'];
$location = $_POST['location'];
$stime = $_POST['stime'];
$etime = $_POST['etime'];
$des = $_POST['descr'];
$sname = $_POST['sname'];

$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'student');
$query = 'insert into event_info (societyID,name,ename,location,date,time,descr,time2) values ("'.$_SESSION['user'].'","'.$sname.'","'.$ename.'","'.$location.'","'.$date.'","'.$des.'","'.$stime.'","'.$etime.'")';
mysqli_query($con,$query);
echo $query;
header("Location: eventmanage.php");

?>