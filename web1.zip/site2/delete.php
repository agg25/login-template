<?php 
$id = $_GET['id'];
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'student');
echo $id;
$query = 'delete  from event_info where id = "'.$id.'"';
echo $query;
mysqli_query($con,$query);
header("Location: eventmanage.php");



?>