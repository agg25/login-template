<?php
session_start();
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'student');
$query = 'select * from stu_info where username = \''.$_SESSION['user'].'\'';
$query2 = 'select * from stu_contact where username = \''.$_SESSION['user'].'\'';
$result = mysqli_query($con,$query);

if(mysqli_affected_rows($con)<=0){
	$fname = $lname  = $branch = $hostel = $year = $society = $insta = $link = $git = $bio = '-';
}
$result2 = mysqli_query($con,$query2);
if(mysqli_affected_rows($con)<=0){
		$mobile = $email = '_';
}
else{
	$row = mysqli_fetch_assoc($result);
	$row2 = mysqli_fetch_assoc($result2);
	$fname = $row['fname'];
	$lname = $row['lname'];
	$email = $row2['email'];
	$mobile = $row2['mobile'];
	$branch = $row['branch'];
	$hostel = $row['hostel'];
	$year = $row['year'];
	$society = $row['society'];
	$insta = $row['insta'];
	$link = $row['link'];
	$git = $row['git'];
	$bio = $row['bio'];
}

$html = '<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Free University Website Template | Smarteyeapps.com</title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <link rel="shortcut icon" href="asset_profile/images/fav.jpg">
    <link rel="stylesheet" href="asset_profile/css/bootstrap.min.css">
    <link rel="stylesheet" href="asset_profile/css/fontawsom-all.min.css">
    <link rel="stylesheet" type="text/css" href="asset_profile/css/style.css" />
</head>

<body>

    <!-- ################# Header Starts Here#######################--->
    <!-- ################# Header Starts Here#######################--->
    <header>
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-12 left-item">
                        <ul>
                            <li><i class="fas fa-envelope-square"></i> sales@smarteyeapps.com</li>
                            <li><i class="fas fa-phone-square"></i> +123 987 887 765</li>
                        </ul>
                    </div>
                    <div class="col-lg-5 d-none d-lg-block right-item">
                        <ul>
                            <li><a><i class="fab fa-github"></i></a></li>
                            <li><a><i class="fab fa-google-plus-g"></i></a></li>
                            <li> <a><i class="fab fa-pinterest-p"></i></a></li>
                            <li><a><i class="fab fa-twitter"></i></a></li>
                            <li> <a><i class="fab fa-facebook-f"></i></a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
        <div id="nav-head" class="header-nav">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-12 nav-img">
                        <img src="assets/images/logo.png" alt="">
                       <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                    </div>
                    <div id="menu" class="col-md-9 d-none d-md-block nav-item">
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            
                            <li><a href="blog.php">Events</a></li>
                            <li><a href="profile.php">My Profile</a></li>
                            <li><a href="about_us.html">About Us</a></li>
                            <li><a href="contact_us.html">Contact Us</a></li>
                            <li><a href="blog.php">Log Out</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </header>


    <!--  ************************* Page Title Starts Here ************************** -->
    <br><br>
    <div class="container-fluid overcover">
        <div class="container profile-box">
           <div class="cover-image row">
               <img src="asset_profile/images/bloogs-6.jpg" alt="">
           </div>
            <div class="row">
                <div class="col-lg-8 col-md-7 detail-px no-padding">
                    <h3>Bio</h3>
                    <p>'.$bio.'</p>
                    
                    <h3 class="mth3">Profile</h3>
                    <div class="fx-ro">
						&nbsp &nbsp &nbsp&nbsp Branch	
                        <div class="detail">
						
                            <b>	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp'.$branch.'</b>
                            
                        </div>
                    </div>
                    <div class="fx-ro">
						&nbsp &nbsp &nbsp&nbsp Hostel	
                        <div class="detail">
						
                            <b>	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp'.$hostel.'</b>
                            
                        </div>
                    </div>
                    <div class="fx-ro">
						&nbsp &nbsp &nbsp&nbsp Year	
                        <div class="detail">
						
						<b>	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp'.$year.'</b>
                            
                        </div>
                    </div>
					<div class="fx-ro">
						&nbsp &nbsp &nbsp&nbsp Societies	
                        <div class="detail">
						
						<b>	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp'.$society.'</b>
                            
                        </div>
                    </div>
                    
                    <h3 class="mth3">Achievements</h3>
                    
                    <div class="fx-ro">
                        <div class="dat">
                            2018
                        </div>
                        <div class="detail">
                            <b>Owasp Hackathon</b>
                            <p>First Price</p>
                        </div>
                    </div>
                    
                    <div class="fx-ro">
                        <div class="dat">
                            2016
                        </div>
                        <div class="detail">
                            <b>Masters Arts Club</b>
                            <p>Londan United Kingdom</p>
                        </div>
                    </div>
                    
                    <div class="fx-ro">
                        <div class="dat">
                            2011
                        </div>
                        <div class="detail">
                            <b>Abraham High School</b>
                            <p>Londan United Kingdom</p>
                        </div>
                    </div>
                    
                    
                    
                </div>
                <div class="col-lg-4 col-md-5 leftgh">
                    <div class="img-box">
                         <img src="asset_profile/images/gallery/gallery_12.jpg" alt="">   
                    </div>
                    <div class="name-det">
                        
                   
                     <h2>'.$fname.' '.$lname.'</h2>
                     
                     <h3>Contact</h3>
                     
                     <p>'.$email.'<br>
                     '.$mobile.'</p>
                     <h3>Change</h3>
                     <a href="form.php"><p>Edit Prifile </p></a>
					 <a href="#"><p>Change Password </p></a>
					 <a href="#"><p>Change Photo</p></a>
					 <a href="#"><p>Change Mobile No</p></a>
					 <a href="emailverification.php"><p>Change Email</p></a>
                     
                     
                     <h3>Social Media</h3>
                     
             
                     
                     <p>instagram@'.$insta.'</p>
                     <p>linkedin@'.$link.'</p>
					 <p>github@'.$git.'</p>
                   
                     
                     
                      
                        
                    </div>
                    
                   
                     
                </div>
            </div>
        </div>
    </div>
   
    <!-- ################# Our Footer Starts Here#######################--->


    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-3 about">
                    <h2>About Us</h2>
                    <p>Phasellus scelerisque ornare nisl sit amet pulvinar. Nunc non scelerisque augue. Proin et sollicitudin velit. </p>

                    <div class="foot-address">
                        <div class="icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="addet">
                            BlueDart
                            Marthandam (K.K District)
                            Tamil Nadu, IND
                        </div>
                    </div>
                    <div class="foot-address">
                        <div class="icon">
                            <i class="far fa-envelope-open"></i>
                        </div>
                        <div class="addet">
                            info@smarteyeapps.com <br>
                            sales@smarteyeapps.com
                        </div>
                    </div>
                    <div class="foot-address">
                        <div class="icon">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <div class="addet">
                            +23 323 43434 <br>
                            +1 3232 434 55
                        </div>
                    </div>
                </div>
                <div class="col-md-3 fotblog">
                    <h2>From latest Blog</h2>
                    <div class="blohjb">
                        <p>dignissim. Integer tempor facilisis malesuada. Proin ac varius velit, tincidunt condimentum</p>
                        <span>22-1-2019</span>
                    </div>
                    <div class="blohjb">
                        <p>dignissim. Integer tempor facilisis malesuada. Proin ac varius velit, tincidunt condimentum</p>
                        <span>22-1-2019</span>
                    </div>
                    <div class="blohjb">
                        <p>dignissim. Integer tempor facilisis malesuada. Proin ac varius velit, tincidunt condimentum</p>
                        <span>22-1-2019</span>
                    </div>
                </div>
                <div class="col-md-3 glink">
                    <ul>
                        <li><a href="index.html"><i class="fas fa-angle-double-right"></i>Home</a></li>
                        <li><a href="about_us.html"><i class="fas fa-angle-double-right"></i>About Us</a></li>
                        <li><a href="services.html"><i class="fas fa-angle-double-right"></i>Services</a></li>
                        <li><a href="blog.html"><i class="fas fa-angle-double-right"></i>Blog</a></li>
                        <li><a href="pricing.html"><i class="fas fa-angle-double-right"></i>Gallery</a></li>
                        <li><a href="contact_us.html"><i class="fas fa-angle-double-right"></i>Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-md-3 tags">
                    <h2>Easy Tags</h2>
                    <ul>
                        <li>Finance</li>
                        <li>Web Design</li>
                        <li>Internet Pro</li>
                        <li>Node Js</li>
                        <li>Java Swing</li>
                        <li>Angular Js</li>
                        <li>Vue Js</li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <div class="copy">
        <div class="container">
            <a href="https://www.smarteyeapps.com/">2015 &copy; All Rights Reserved | Designed and Developed by Smarteyeapps</a>

            <span>
                <a><i class="fab fa-github"></i></a>
                <a><i class="fab fa-google-plus-g"></i></a>
                <a><i class="fab fa-pinterest-p"></i></a>
                <a><i class="fab fa-twitter"></i></a>
                <a><i class="fab fa-facebook-f"></i></a>
            </span>
        </div>

    </div>

</body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/slider/js/owl.carousel.min.js"></script>
<script src="assets/js/script.js"></script>
<script src="asset_profile/js/jquery-3.2.1.min.js"></script>
<script src="asset_profile/js/popper.min.js"></script>
<script src="asset_profile/js/bootstrap.min.js"></script>
<script src="asset_profile/js/script.js"></script>


</html>';
echo $html;
mysqli_close($con);
?>