<?php
session_start();
$con = mysqli_connect('localhost','root');
mysqli_select_db($con,'student');
$query = 'select * from stu_info where username = \''.$_SESSION['user'].'\'';
$result = mysqli_query($con,$query);
if(mysqli_affected_rows($con)<=0){
	$fname = $lname = $email = $mobile = $branch = $hostel = $year = $society = $insta = $link = $git = $bio = '_';
}
else{
	$row = mysqli_fetch_assoc($result);
	$fname = $row['fname'];
	$lname = $row['lname'];
	$email = $row['email'];
	$mobile = $row['mobile'];
	$branch = $row['brach'];
	$hostel = $row['hostel'];
	$year = $row['year'];
	$society = $row['society'];
	$insta = $row['insta'];
	$link = $row['link'];
	$git = $row['git'];
	$bio = $row['bio'];
}
$html = '<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Free University Website Template | Smarteyeapps.com</title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<style>
	.contform{
		width:60%;
		margin-left:250px;
	}
	
	</style>
	
</head>

<body>
    
    <!-- ################# Header Starts Here#######################--->
    <header>
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-12 left-item">
                        <ul>
                            <li><i class="fas fa-envelope-square"></i> sales@smarteyeapps.com</li>
                            <li><i class="fas fa-phone-square"></i> +123 987 887 765</li>
                        </ul>
                    </div>
                    <div class="col-lg-5 d-none d-lg-block right-item">
                        <ul>
                            <li><a><i class="fab fa-github"></i></a></li>
                            <li><a><i class="fab fa-google-plus-g"></i></a></li>
                            <li> <a><i class="fab fa-pinterest-p"></i></a></li>
                            <li><a><i class="fab fa-twitter"></i></a></li>
                            <li> <a><i class="fab fa-facebook-f"></i></a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
        <div id="nav-head" class="header-nav">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-12 nav-img">
                        <img src="assets/images/logo.png" alt="">
                       <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                    </div>
                    <div id="menu" class="col-md-9 d-none d-md-block nav-item">
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            
                            <li><a href="blog.php">Events</a></li>
                            <li><a href="profile.html">My Profile</a></li>
                            <li><a href="about_us.html">About Us</a></li>
                            <li><a href="contact_us.html">Contact Us</a></li>
                            <li><a href="stu_form/infoform.html">Log Out</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </header>
	<!------------------------------------------------------------>
	
	<br><br><br><br><br><br>
	<div class="contform">
	<div class="container-md">
		<form method="post" action="formaction.php">
		  <div class="form-row">
			<div class="col">
			  <input type="text" class="form-control" placeholder="'.$fname.'" name="fname" value="'.$fname.'">
			</div>
			<div class="col">
			  <input type="text" class="form-control" placeholder="'.$lname.'" name="lname" value="'.$lname.'">
			</div>
		  </div>
		  
		  <div class="form-row">
			<div class="col">
			  <input type="text" class="form-control" placeholder="'.$branch.'" name="branch" value="'.$branch.'">
			</div>
			<div class="col">
			  <input type="text" class="form-control" placeholder="'.$year.'" name="year" value="'.$year.'">
			</div>
			<div class="col">
			  <input type="text" class="form-control" placeholder="'.$hostel.'" name="hostel" value="'.$hostel.'">
			</div>
			<div class="col">
			  <input type="text" class="form-control" placeholder=value="'.$society.'" name="society" value="'.$society.'">
			</div>
		  </div>
		   <div class="form-row">
			<div class="col">
			  <input type="text" class="form-control" placeholder=value="'.$insta.'" name="insta" value="'.$insta.'">
			</div>
			<div class="col">
			  <input type="text" class="form-control" placeholder="'.$link.'" name="link" value="'.$link.'">
			</div>
			<div class="col">
			  <input type="text" class="form-control" placeholder="'.$git.'" name="git" value="'.$git.'">
			</div>
			
		  </div>
		  
		   <div class="form-group">
		<textarea class="form-control" id="exampleFormControlTextarea1" value="'.$bio.'" placeholder="'.$bio.'" rows="3" name="bio"></textarea>
		</div><br><div class="form-row">
		  <input type="submit" class="btn btn-primary" name="SAVE" value="SAVE"></div>
		</form>
	
	
	
	
	
	</div>
	</div>';
echo $html;
	
?>