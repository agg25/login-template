<?php
function cards($month,$date,$year,$event,$stime,$etime,$location,$society,$img){
$card = '<div class="blog-card row">
                
                        <div class="col-2">
                           <div class="date-box">
                                <span>'.$month.'</span>
                                <p>'.$date.'</p>
                                <small>'.$year.'</small>
                           </div>
                           
                        </div>
                        <div class="col-7 setv">
                            <h4>'.$event.'</h4>
                            <ul>
                                <li>Timmings -  '.$stime.' - '.$etime.'</li>
                                <li>At - '.$location.'</li>
                                <li>By '.$society.'</li>
                            </ul>
                        </div>
                        <div class="col-3 img-cv">
                            <img src='.$img.' alt="">
                        </div>
                    </div>';
    return $card;
}
	$months = array('','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
    $con = mysqli_connect("localhost","root");
    mysqli_select_db($con,'student');
    $result = mysqli_query($con,'select * from event_info');
	$str = '';
    while($row = mysqli_fetch_assoc($result)){
		$event = $row['ename'];
		$society = $row['name'];
		$location = $row['location'];
		$stime = $row['time'];
		$etime = $row['time2'];
		$d = date_parse_from_format("Y-m-d", $row['date']);
		$date = $d['day'];
		$year = $d['year'];
		$month = $months[$d['month']];
		$img = 'assets/images/cources/cource-1.jpg';
		$str = $str.cards($month,$date,$year,$event,$stime,$etime,$location,$society,$img);
	}

?>