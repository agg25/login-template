<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Free University Website Template | Smarteyeapps.com</title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>

<body>
    
    <!-- ################# Header Starts Here#######################--->
    <header>
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-12 left-item">
                        <ul>
                            <li><i class="fas fa-envelope-square"></i> sales@smarteyeapps.com</li>
                            <li><i class="fas fa-phone-square"></i> +123 987 887 765</li>
                        </ul>
                    </div>
                    <div class="col-lg-5 d-none d-lg-block right-item">
                        <ul>
                            <li><a><i class="fab fa-github"></i></a></li>
                            <li><a><i class="fab fa-google-plus-g"></i></a></li>
                            <li> <a><i class="fab fa-pinterest-p"></i></a></li>
                            <li><a><i class="fab fa-twitter"></i></a></li>
                            <li> <a><i class="fab fa-facebook-f"></i></a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
        <div id="nav-head" class="header-nav">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-12 nav-img">
                        <img src="assets/images/logo.png" alt="">
                       <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                    </div>
                    <div id="menu" class="col-md-9 d-none d-md-block nav-item">
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            
                            <li><a href="blog.php">Events</a></li>
                            <li><a href="profile.php">Profile</a></li>
                            <li><a href="eventmanage.php">Event Manager</a></li>
                            <li><a href="contact_us.html">Contact Us</a></li>
                            <li><a href="form.html">Log Out</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

    </header>
    
    


    <!--  ************************* Page Title Starts Here ************************** -->
    <br><br><br><br>
    <br>

   <div class="our-blog bb3 pc2">
    <div class="container">
         
        
        <div class="row-blog row">
            <div class="col-md-10 vbf mx-auto">
                
            <?php
                include 'cards.php';    
                echo $str;
            ?>
                 
                    
                    
                 
                
            </div>
        </div>
    </div>
</div>
   
   
    <!-- ################# Our Footer Starts Here#######################--->


    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-3 about">
                    <h2>About Us</h2>
                    <p>Phasellus scelerisque ornare nisl sit amet pulvinar. Nunc non scelerisque augue. Proin et sollicitudin velit. </p>

                    <div class="foot-address">
                        <div class="icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="addet">
                            BlueDart
                            Marthandam (K.K District)
                            Tamil Nadu, IND
                        </div>
                    </div>
                    <div class="foot-address">
                        <div class="icon">
                            <i class="far fa-envelope-open"></i>
                        </div>
                        <div class="addet">
                            info@smarteyeapps.com <br>
                            sales@smarteyeapps.com
                        </div>
                    </div>
                    <div class="foot-address">
                        <div class="icon">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <div class="addet">
                            +23 323 43434 <br>
                            +1 3232 434 55
                        </div>
                    </div>
                </div>
                <div class="col-md-3 fotblog">
                    <h2>From latest Blog</h2>
                    <div class="blohjb">
                        <p>dignissim. Integer tempor facilisis malesuada. Proin ac varius velit, tincidunt condimentum</p>
                        <span>22-1-2019</span>
                    </div>
                    <div class="blohjb">
                        <p>dignissim. Integer tempor facilisis malesuada. Proin ac varius velit, tincidunt condimentum</p>
                        <span>22-1-2019</span>
                    </div>
                    <div class="blohjb">
                        <p>dignissim. Integer tempor facilisis malesuada. Proin ac varius velit, tincidunt condimentum</p>
                        <span>22-1-2019</span>
                    </div>
                </div>
                <div class="col-md-3 glink">
                    <ul>
                        <li><a href="index.html"><i class="fas fa-angle-double-right"></i>Home</a></li>
                        <li><a href="about_us.html"><i class="fas fa-angle-double-right"></i>About Us</a></li>
                        <li><a href="services.html"><i class="fas fa-angle-double-right"></i>Services</a></li>
                        <li><a href="blog.html"><i class="fas fa-angle-double-right"></i>Blog</a></li>
                        <li><a href="pricing.html"><i class="fas fa-angle-double-right"></i>Gallery</a></li>
                        <li><a href="contact_us.html"><i class="fas fa-angle-double-right"></i>Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-md-3 tags">
                    <h2>Easy Tags</h2>
                    <ul>
                        <li>Finance</li>
                        <li>Web Design</li>
                        <li>Internet Pro</li>
                        <li>Node Js</li>
                        <li>Java Swing</li>
                        <li>Angular Js</li>
                        <li>Vue Js</li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <div class="copy">
        <div class="container">
            <a href="https://www.smarteyeapps.com/">2015 &copy; All Rights Reserved | Designed and Developed by Smarteyeapps</a>

            <span>
                <a><i class="fab fa-github"></i></a>
                <a><i class="fab fa-google-plus-g"></i></a>
                <a><i class="fab fa-pinterest-p"></i></a>
                <a><i class="fab fa-twitter"></i></a>
                <a><i class="fab fa-facebook-f"></i></a>
            </span>
        </div>

    </div>

</body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/slider/js/owl.carousel.min.js"></script>
<script src="assets/js/script.js"></script>


</html>