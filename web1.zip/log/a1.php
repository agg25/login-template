<?php
header("Location: ../site/indeededx.html");
